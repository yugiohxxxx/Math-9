<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<c:set var="pageTitle" value="Trang chủ"/>
<%@ include file="/WEB-INF/jspf/layout-header.jspf" %>
<h3 class="mb-1">Xin chào, <c:out value="${sessionScope.user.fullName}"/> 👋</h3>
<p class="text-muted">Cùng học Toán 9 hôm nay nhé!</p>
<div class="row g-3 mb-4">
  <div class="col-md-4"><div class="card h-100"><div class="card-body text-center">
    <i class="bi bi-journal-richtext fs-1 text-primary"></i><h5 class="mt-2">Bài giảng</h5>
    <p class="text-muted">Xem bài giảng, video theo chủ đề</p><a class="btn btn-primary" href="${ctx}/student/lessons">Vào học</a></div></div></div>
  <div class="col-md-4"><div class="card h-100"><div class="card-body text-center">
    <i class="bi bi-pencil-square fs-1 text-success"></i><h5 class="mt-2">Luyện tập</h5>
    <p class="text-muted">Trắc nghiệm &amp; tự luận có AI hỗ trợ</p><a class="btn btn-success" href="${ctx}/student/practice">Luyện tập</a></div></div></div>
  <div class="col-md-4"><div class="card h-100"><div class="card-body text-center">
    <i class="bi bi-graph-up fs-1 text-warning"></i><h5 class="mt-2">Tiến độ</h5>
    <p class="text-muted">Theo dõi bài đã xong / chưa xong</p><a class="btn btn-warning" href="${ctx}/student/progress">Xem tiến độ</a></div></div></div>
</div>
<div class="card"><div class="card-header">Tiến độ học tập tổng quan</div><div class="card-body">
  <div class="progress" style="height:24px"><div class="progress-bar bg-success" style="width:${empty overallPercent?0:overallPercent}%">${empty overallPercent?0:overallPercent}%</div></div>
</div></div>
<%@ include file="/WEB-INF/jspf/layout-footer.jspf" %>
