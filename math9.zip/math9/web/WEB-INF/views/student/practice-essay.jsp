<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<c:set var="pageTitle" value="Luyện tập tự luận"/>
<%@ include file="/WEB-INF/jspf/layout-header.jspf" %>
<div class="d-flex justify-content-between"><h3>Tự luận: <c:out value="${practice.topicTitle}"/></h3>
  <span class="text-muted">Câu ${currentIndex} / ${totalQuestions}</span></div>
<div class="card mb-3 border-primary"><div class="card-header bg-primary text-white">Đề bài</div><div class="card-body">
  <div>${question.content}</div>
  <c:if test="${not empty question.imageUrl}"><img src="${ctx}/${question.imageUrl}" class="img-fluid mt-2" style="max-height:240px"></c:if>
</div></div>

<%-- Các bước đã giải: AI dừng sau mỗi bước, học sinh nhập số liệu rồi giải tiếp --%>
<c:forEach var="s" items="${steps}">
  <div class="card mb-2"><div class="card-body">
    <div class="mb-2"><span class="badge text-bg-primary">Bước ${s.stepNo}</span> ${s.aiPrompt}</div>
    <c:if test="${not empty s.studentInput}"><div class="alert alert-light border mb-2"><strong>Bạn nhập:</strong> <c:out value="${s.studentInput}"/></div></c:if>
    <c:if test="${not empty s.aiResponse}"><div class="alert alert-success mb-0"><i class="bi bi-robot"></i> ${s.aiResponse}</div></c:if>
  </div></div>
</c:forEach>

<c:if test="${not finished}">
<div class="card border-success"><div class="card-body">
  <c:if test="${not empty currentPrompt}"><div class="alert alert-warning"><i class="bi bi-robot"></i> <strong>AI yêu cầu:</strong> ${currentPrompt}</div></c:if>
  <form method="post" action="${ctx}/student/practice-essay" enctype="multipart/form-data">
    <input type="hidden" name="sessionId" value="${practice.sessionId}">
    <input type="hidden" name="questionId" value="${question.questionId}">
    <div class="mb-3"><label class="form-label">Nhập số liệu / kết quả của bước này</label>
      <textarea class="form-control" name="studentInput" rows="3" placeholder="Ví dụ: x = 2, y = 3"></textarea></div>
    <div class="mb-3"><label class="form-label">Hoặc tải ảnh bài giải viết tay</label>
      <input type="file" class="form-control" name="image" accept="image/*" id="imgIn">
      <img id="preview" class="img-thumbnail mt-2 d-none" style="max-height:180px"></div>
    <button class="btn btn-success" name="action" value="next"><i class="bi bi-arrow-right-circle"></i> Gửi &amp; giải tiếp</button>
    <button class="btn btn-outline-secondary" name="action" value="finish">Kết thúc câu này</button>
  </form></div></div>
</c:if>

<c:if test="${finished}">
  <div class="text-center mt-3">
    <c:choose>
      <c:when test="${hasNext}"><a class="btn btn-primary" href="${ctx}/student/practice-essay?sessionId=${practice.sessionId}&index=${currentIndex+1}">Câu tiếp theo &raquo;</a></c:when>
      <c:otherwise><a class="btn btn-success" href="${ctx}/student/practice-result?sessionId=${practice.sessionId}">Xem kết quả</a></c:otherwise>
    </c:choose></div>
</c:if>
<%@ include file="/WEB-INF/jspf/layout-footer.jspf" %>
<script>
document.getElementById('imgIn')?.addEventListener('change',function(e){
  var f=e.target.files[0]; if(!f) return; var p=document.getElementById('preview');
  p.src=URL.createObjectURL(f); p.classList.remove('d-none');});
</script>
