<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<c:set var="pageTitle" value="Luyện tập trắc nghiệm"/>
<%@ include file="/WEB-INF/jspf/layout-header.jspf" %>
<h3 class="mb-3">Trắc nghiệm: <c:out value="${practice.topicTitle}"/></h3>
<form method="post" action="${ctx}/student/practice-submit" id="mcqForm">
  <input type="hidden" name="sessionId" value="${practice.sessionId}">
  <c:forEach var="q" items="${questions}" varStatus="st">
    <div class="card mb-3"><div class="card-body">
      <h6>Câu ${st.count} <span class="badge text-bg-light">Mức ${q.level}</span></h6>
      <div class="mb-2">${q.content}</div>
      <c:if test="${not empty q.imageUrl}"><img src="${ctx}/${q.imageUrl}" class="img-fluid mb-2" style="max-height:200px"></c:if>
      <c:forEach var="o" items="${q.options}">
        <div class="form-check">
          <input class="form-check-input" type="radio" name="q${q.questionId}" id="o${o.optionId}" value="${o.optionId}">
          <label class="form-check-label" for="o${o.optionId}"><strong>${o.optionLabel}.</strong> <c:out value="${o.content}"/></label></div>
      </c:forEach>
    </div></div>
  </c:forEach>
  <button class="btn btn-primary btn-lg" onclick="return confirm('Nộp bài?')"><i class="bi bi-send"></i> Nộp bài</button>
</form>
<%@ include file="/WEB-INF/jspf/layout-footer.jspf" %>
