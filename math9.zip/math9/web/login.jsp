<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Đăng nhập - MathTutor</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
</head>
<body class="bg-primary-subtle d-flex align-items-center" style="min-height:100vh">
<div class="container" style="max-width:420px">
  <div class="card shadow">
    <div class="card-body p-4">
      <h3 class="text-center text-primary mb-1"><i class="bi bi-calculator"></i> MathTutor</h3>
      <p class="text-center text-muted">Gia sư Toán 9</p>
      <c:if test="${not empty error}">
        <div class="alert alert-danger py-2">${error}</div>
      </c:if>
      <form action="${pageContext.request.contextPath}/login" method="post">
        <div class="mb-3">
          <label class="form-label">Tên đăng nhập</label>
          <input type="text" name="username" class="form-control" required autofocus>
        </div>
        <div class="mb-3">
          <label class="form-label">Mật khẩu</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button class="btn btn-primary w-100" type="submit">Đăng nhập</button>
      </form>
    </div>
  </div>
</div>
</body>
</html>
