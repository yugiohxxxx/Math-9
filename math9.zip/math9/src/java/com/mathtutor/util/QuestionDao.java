package com.mathtutor.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QuestionDao {

    /** opts: 4 phần tử A-D (chỉ dùng cho mcq), correct: "A".."D". */
    public static long insert(int topicId, Integer lessonId, String type, String content, String imageUrl,
                              int level, String solution, String source, int createdBy,
                              String[] opts, String correct) {
        long id = Db.insert("INSERT INTO Questions(TopicId,LessonId,QuestionType,Content,ImageUrl,Level,Solution,Source,CreatedBy) "
                + "VALUES(?,?,?,?,?,?,?,?,?)", topicId, lessonId, type, content, imageUrl, level, solution, source, createdBy);
        if ("mcq".equals(type) && opts != null) {
            String[] labels = {"A", "B", "C", "D"};
            for (int i = 0; i < 4; i++) {
                if (Text.blank(opts[i])) continue;
                Db.update("INSERT INTO QuestionOptions(QuestionId,OptionLabel,Content,IsCorrect) VALUES(?,?,?,?)",
                        id, labels[i], opts[i].trim(), labels[i].equalsIgnoreCase(correct) ? 1 : 0);
            }
        }
        return id;
    }

    /**
     * Phân tích đầu ra AI. Mỗi câu bắt đầu bằng dòng ###, gồm các dòng Q:, A:, B:, C:, D:, ANS:, SOL:.
     * Trả về số câu đã thêm.
     */
    public static int importFromAi(String text, int topicId, String type, int level, String source, int createdBy) {
        if (text == null) return 0;
        text = text.replace("```", "");
        int added = 0;
        for (String block : text.split("(?m)^\\s*###.*$")) {
            if (block.trim().isEmpty()) continue;
            String q = Text.section(block, "Q", "A", "B", "C", "D", "ANS", "SOL");
            if (Text.blank(q)) continue;
            String sol = Text.section(block, "SOL", "Q", "A", "B", "C", "D", "ANS");
            if ("mcq".equals(type)) {
                String[] o = {
                    Text.section(block, "A", "B", "C", "D", "ANS", "SOL", "Q"),
                    Text.section(block, "B", "A", "C", "D", "ANS", "SOL", "Q"),
                    Text.section(block, "C", "A", "B", "D", "ANS", "SOL", "Q"),
                    Text.section(block, "D", "A", "B", "C", "ANS", "SOL", "Q")};
                String ans = Text.section(block, "ANS", "A", "B", "C", "D", "SOL", "Q");
                if (o[0] == null || o[1] == null || ans == null || ans.isEmpty()) continue;
                insert(topicId, null, "mcq", Text.aiToHtml(q), null, level, Text.aiToHtml(sol), source, createdBy,
                        o, ans.trim().substring(0, 1).toUpperCase());
            } else {
                insert(topicId, null, "essay", Text.aiToHtml(q), null, level, Text.aiToHtml(sol), source, createdBy, null, null);
            }
            added++;
        }
        return added;
    }
}
