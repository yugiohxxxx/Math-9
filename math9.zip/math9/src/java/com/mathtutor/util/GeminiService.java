package com.mathtutor.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;

/** Gọi Gemini API. Cấu hình (API key, model, prompt) lấy từ bảng AiConfigs do Admin chỉnh. */
public class GeminiService {

    public static class Cfg {
        public String key, model, url, prompt;
        public boolean ready() { return key != null; }
    }

    private static boolean validKey(Object k) {
        if (k == null) return false;
        String s = k.toString().trim();
        return !s.isEmpty() && !s.equals("YOUR_API_KEY");
    }

    public static Cfg load(String promptType) {
        Cfg c = new Cfg();
        Map<String, Object> row = Db.one("SELECT TOP 1 ApiKey, ModelName, ApiUrl, PromptContent FROM AiConfigs "
                + "WHERE PromptType=? AND IsActive=1 ORDER BY ConfigId DESC", promptType);
        c.model = "gemini-2.5-flash";
        c.prompt = "";
        if (row != null) {
            if (row.get("modelName") != null) c.model = row.get("modelName").toString();
            if (row.get("apiUrl") != null) c.url = row.get("apiUrl").toString();
            if (row.get("promptContent") != null) c.prompt = row.get("promptContent").toString();
            if (validKey(row.get("apiKey"))) c.key = row.get("apiKey").toString().trim();
        }
        if (c.key == null) { // dùng key của bất kỳ cấu hình nào đã nhập
            Map<String, Object> any = Db.one("SELECT TOP 1 ApiKey FROM AiConfigs WHERE IsActive=1 "
                    + "AND ApiKey NOT IN ('', 'YOUR_API_KEY') ORDER BY ConfigId DESC");
            if (any != null) c.key = any.get("apiKey").toString().trim();
        }
        if (c.key == null && validKey(System.getenv("GEMINI_API_KEY"))) c.key = System.getenv("GEMINI_API_KEY");
        return c;
    }

    /** Trả về text AI hoặc null nếu chưa có key / gọi lỗi. data/mime: tệp đính kèm (ảnh, pdf) - có thể null. */
    public static String generate(Cfg c, String prompt, byte[] data, String mime) {
        if (c == null || !c.ready()) return null;
        try {
            String endpoint = (c.url != null && c.url.startsWith("http")) ? c.url
                    : "https://generativelanguage.googleapis.com/v1beta/models/" + c.model + ":generateContent";
            endpoint += (endpoint.contains("?") ? "&" : "?") + "key=" + c.key;

            StringBuilder body = new StringBuilder("{\"contents\":[{\"parts\":[{\"text\":\"")
                    .append(esc(prompt)).append("\"}");
            if (data != null && mime != null)
                body.append(",{\"inline_data\":{\"mime_type\":\"").append(mime).append("\",\"data\":\"")
                        .append(Base64.getEncoder().encodeToString(data)).append("\"}}");
            body.append("]}]}");

            HttpURLConnection h = (HttpURLConnection) new URL(endpoint).openConnection();
            h.setRequestMethod("POST");
            h.setConnectTimeout(15000);
            h.setReadTimeout(90000);
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            try (OutputStream os = h.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = h.getResponseCode();
            InputStream in = code < 400 ? h.getInputStream() : h.getErrorStream();
            String resp = new String(Text.readAll(in), StandardCharsets.UTF_8);
            if (code >= 400) {
                System.err.println("[Gemini] HTTP " + code + ": " + resp);
                return null;
            }
            return extractText(resp);
        } catch (Exception e) {
            System.err.println("[Gemini] " + e);
            return null;
        }
    }

    static String esc(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            switch (ch) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (ch < 0x20) sb.append(String.format("\\u%04x", (int) ch)); else sb.append(ch);
            }
        }
        return sb.toString();
    }

    /** Lấy chuỗi JSON đầu tiên sau "text": trong phản hồi. */
    static String extractText(String json) {
        int i = json.indexOf("\"text\"");
        if (i < 0) return null;
        i = json.indexOf('"', json.indexOf(':', i) + 1);
        if (i < 0) return null;
        StringBuilder sb = new StringBuilder();
        for (int p = i + 1; p < json.length(); p++) {
            char ch = json.charAt(p);
            if (ch == '"') return sb.toString();
            if (ch == '\\' && p + 1 < json.length()) {
                char n = json.charAt(++p);
                switch (n) {
                    case 'n': sb.append('\n'); break;
                    case 't': sb.append('\t'); break;
                    case 'r': sb.append('\r'); break;
                    case 'u': sb.append((char) Integer.parseInt(json.substring(p + 1, p + 5), 16)); p += 4; break;
                    default: sb.append(n);
                }
            } else sb.append(ch);
        }
        return null;
    }
}
