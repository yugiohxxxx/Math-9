package com.mathtutor.servlet;

import com.mathtutor.util.*;
import java.io.IOException;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;

@WebServlet("/manage/question-form")
@MultipartConfig(maxFileSize = 10 * 1024 * 1024)
public class QuestionFormServlet extends BaseServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = intParam(req, "id");
        if (id != null) {
            Map<String, Object> q = Db.one("SELECT * FROM Questions WHERE QuestionId=?", id);
            if (q != null)
                q.put("options", Db.query("SELECT OptionId, OptionLabel, Content, IsCorrect FROM QuestionOptions WHERE QuestionId=? ORDER BY OptionLabel", id));
            req.setAttribute("q", q);
        }
        req.setAttribute("topics", Db.query("SELECT TopicId, Title FROM Topics WHERE IsActive=1 ORDER BY ChapterId, SortOrder"));
        view(req, resp, "manage/question-form.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = intParam(req, "id");
        String type = "essay".equals(param(req, "questionType")) ? "essay" : "mcq";
        Part img = req.getPart("image");
        String imageUrl = store(partBytes(img), partName(img), "questions");
        String content = req.getParameter("content");
        String solution = Text.nullIfBlank(req.getParameter("solution"));
        int level = intParam(req, "level") == null ? 1 : intParam(req, "level");
        String[] labels = {"A", "B", "C", "D"};
        String[] opts = new String[4];
        for (int i = 0; i < 4; i++) opts[i] = req.getParameter("opt" + labels[i]);
        String correct = param(req, "correct");

        if ("mcq".equals(type)) {
            boolean ok = correct != null && !Text.blank(opts["ABCD".indexOf(correct)]);
            if (!ok) {
                flash(req, "Câu trắc nghiệm cần có đáp án đúng và nội dung của đáp án đó.");
                redirect(req, resp, "/manage/question-form" + (id == null ? "" : "?id=" + id));
                return;
            }
        }
        if (id == null) {
            QuestionDao.insert(intParam(req, "topicId"), null, type, content, imageUrl, level, solution, "manual", uid(req), opts, correct);
        } else {
            Db.update("UPDATE Questions SET TopicId=?, QuestionType=?, Content=?, Level=?, Solution=?, ImageUrl=ISNULL(?,ImageUrl) WHERE QuestionId=?",
                    intParam(req, "topicId"), type, content, level, solution, imageUrl, id);
            if ("mcq".equals(type)) {
                for (int i = 0; i < 4; i++) { // cập nhật tại chỗ để không vỡ khoá ngoại với bài đã làm
                    Map<String, Object> ex = Db.one("SELECT OptionId FROM QuestionOptions WHERE QuestionId=? AND OptionLabel=?", id, labels[i]);
                    int isC = labels[i].equals(correct) ? 1 : 0;
                    if (Text.blank(opts[i])) continue;
                    if (ex != null) Db.update("UPDATE QuestionOptions SET Content=?, IsCorrect=? WHERE OptionId=?", opts[i].trim(), isC, ex.get("optionId"));
                    else Db.update("INSERT INTO QuestionOptions(QuestionId,OptionLabel,Content,IsCorrect) VALUES(?,?,?,?)", id, labels[i], opts[i].trim(), isC);
                }
            }
        }
        flash(req, "Đã lưu câu hỏi.");
        redirect(req, resp, "/manage/questions");
    }
}
