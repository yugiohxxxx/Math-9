package com.mathtutor.servlet;

import com.mathtutor.util.*;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/admin/ai-config")
public class AiConfigServlet extends BaseServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("configs", Db.query("SELECT ConfigId, Provider, ModelName, ApiKey, ApiUrl, PromptType, PromptContent, IsActive "
                + "FROM AiConfigs ORDER BY ConfigId"));
        view(req, resp, "admin/ai-config.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = intParam(req, "configId");
        int active = req.getParameter("active") != null ? 1 : 0;
        if (id != null) {
            Db.update("UPDATE AiConfigs SET Provider=?, ModelName=?, ApiKey=?, ApiUrl=?, PromptContent=?, IsActive=?, UpdatedBy=?, UpdatedAt=GETDATE() WHERE ConfigId=?",
                    param(req, "provider"), param(req, "modelName"), param(req, "apiKey"), Text.nullIfBlank(req.getParameter("apiUrl")),
                    req.getParameter("promptContent"), active, uid(req), id);
        } else {
            Db.update("INSERT INTO AiConfigs(Provider,ApiKey,ModelName,PromptType,PromptContent,IsActive,UpdatedBy) VALUES(?,?,?,?,?,?,?)",
                    param(req, "provider"), param(req, "apiKey"), param(req, "modelName"), param(req, "promptType"),
                    req.getParameter("promptContent"), active, uid(req));
        }
        flash(req, "Đã lưu cấu hình AI.");
        redirect(req, resp, "/admin/ai-config");
    }
}
