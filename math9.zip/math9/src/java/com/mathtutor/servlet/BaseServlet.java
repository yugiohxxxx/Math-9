package com.mathtutor.servlet;

import com.mathtutor.util.Db;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

public abstract class BaseServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            super.service(req, resp);
        } catch (Db.DbException e) {
            log("Lỗi CSDL", e);
            fail(req, resp, 500, "Lỗi cơ sở dữ liệu: " + e.getMessage());
        } catch (RuntimeException e) {
            log("Lỗi", e);
            fail(req, resp, 500, "Đã xảy ra lỗi: " + e);
        }
    }

    protected void fail(HttpServletRequest req, HttpServletResponse resp, int code, String msg) throws ServletException, IOException {
        resp.setStatus(code);
        req.setAttribute("code", code);
        req.setAttribute("message", msg);
        view(req, resp, "common/error.jsp");
    }

    protected void view(HttpServletRequest req, HttpServletResponse resp, String jsp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/" + jsp).forward(req, resp);
    }

    protected void redirect(HttpServletRequest req, HttpServletResponse resp, String path) throws IOException {
        resp.sendRedirect(req.getContextPath() + path);
    }

    @SuppressWarnings("unchecked")
    protected Map<String, Object> user(HttpServletRequest req) {
        return (Map<String, Object>) req.getSession().getAttribute("user");
    }

    protected int uid(HttpServletRequest req) { return ((Number) user(req).get("userId")).intValue(); }

    protected String role(HttpServletRequest req) { return String.valueOf(user(req).get("roleName")); }

    protected void flash(HttpServletRequest req, String msg) { req.getSession().setAttribute("flash", msg); }

    protected Integer intParam(HttpServletRequest req, String name) {
        try {
            String v = req.getParameter(name);
            return (v == null || v.trim().isEmpty()) ? null : Integer.valueOf(v.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    protected String param(HttpServletRequest req, String name) {
        String v = req.getParameter(name);
        return v == null ? null : v.trim();
    }

    /** Đọc nội dung của part upload (null nếu không có tệp). */
    protected byte[] partBytes(Part p) throws IOException {
        if (p == null || p.getSize() == 0) return null;
        return com.mathtutor.util.Text.readAll(p.getInputStream());
    }

    protected String partName(Part p) {
        String n = p == null ? null : p.getSubmittedFileName();
        return n == null ? "" : n;
    }

    protected static final Set<String> ALLOWED = new HashSet<>(Arrays.asList("png", "jpg", "jpeg", "gif", "webp", "pdf"));

    /** Lưu tệp vào webapp/uploads/<sub>/, trả về đường dẫn tương đối "uploads/<sub>/xxx.ext" (null nếu không hợp lệ). */
    protected String store(byte[] data, String origName, String sub) throws IOException {
        if (data == null || data.length == 0) return null;
        String ext = origName.contains(".") ? origName.substring(origName.lastIndexOf('.') + 1).toLowerCase() : "";
        if (!ALLOWED.contains(ext)) return null;
        String rel = "uploads/" + sub + "/" + UUID.randomUUID() + "." + ext;
        File f = new File(getServletContext().getRealPath("/" + rel));
        f.getParentFile().mkdirs();
        Files.write(f.toPath(), data);
        return rel;
    }

    protected String mimeOf(String path) {
        String p = path == null ? "" : path.toLowerCase();
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".gif")) return "image/gif";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".pdf")) return "application/pdf";
        return "image/jpeg";
    }
}
