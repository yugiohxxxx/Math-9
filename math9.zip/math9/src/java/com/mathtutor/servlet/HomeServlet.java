package com.mathtutor.servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/home")
public class HomeServlet extends BaseServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String r = role(req);
        redirect(req, resp, r.equals("admin") ? "/admin/dashboard" : r.equals("teacher") ? "/teacher/dashboard" : "/student/home");
    }
}
