package com.mathtutor.servlet;

import com.mathtutor.util.*;
import java.io.IOException;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/manage/questions")
public class QuestionsServlet extends BaseServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder sql = new StringBuilder("SELECT q.QuestionId, q.Content, t.Title AS TopicTitle, q.QuestionType, q.Level, q.Source "
                + "FROM Questions q JOIN Topics t ON t.TopicId=q.TopicId WHERE q.IsActive=1");
        List<Object> p = new ArrayList<>();
        if (intParam(req, "topicId") != null) { sql.append(" AND q.TopicId=?"); p.add(intParam(req, "topicId")); }
        if (!Text.blank(req.getParameter("type"))) { sql.append(" AND q.QuestionType=?"); p.add(param(req, "type")); }
        if (intParam(req, "level") != null) { sql.append(" AND q.Level=?"); p.add(intParam(req, "level")); }
        sql.append(" ORDER BY q.QuestionId DESC");
        req.setAttribute("questions", Db.query(sql.toString(), p.toArray()));
        req.setAttribute("topics", Db.query("SELECT TopicId, Title FROM Topics WHERE IsActive=1 ORDER BY ChapterId, SortOrder"));
        view(req, resp, "manage/questions.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String a = param(req, "action");
        if ("delete".equals(a) && intParam(req, "id") != null) {
            Db.update("UPDATE Questions SET IsActive=0 WHERE QuestionId=?", intParam(req, "id")); // xoá mềm để giữ lịch sử luyện tập
            flash(req, "Đã xoá câu hỏi.");
        } else if ("aiGenerate".equals(a)) {
            flash(req, aiGenerate(req));
        }
        redirect(req, resp, "/manage/questions");
    }

    private String aiGenerate(HttpServletRequest req) {
        Integer topicId = intParam(req, "topicId"), level = intParam(req, "level"), count = intParam(req, "count");
        String type = "essay".equals(param(req, "type")) ? "essay" : "mcq";
        if (topicId == null || level == null) return "Thiếu thông tin.";
        if (count == null || count < 1) count = 5;
        GeminiService.Cfg cfg = GeminiService.load("generate_question");
        if (!cfg.ready()) return "Chưa cấu hình API key trong mục Cấu hình AI.";
        String topic = (String) Db.one("SELECT Title FROM Topics WHERE TopicId=?", topicId).get("title");
        String[] lv = {"", "nhận biết", "thông hiểu", "vận dụng", "vận dụng cao"};
        String spec = cfg.prompt + "\n\nMôn Toán lớp 9, chủ đề: " + topic + ". Hãy tạo " + count + " câu hỏi "
                + ("mcq".equals(type) ? "trắc nghiệm 4 đáp án" : "tự luận") + " mức độ " + lv[Math.max(1, Math.min(4, level))] + ".\n"
                + "Viết công thức bằng LaTeX trong dấu $...$. Trả về ĐÚNG định dạng, mỗi câu bắt đầu bằng một dòng ###:\n"
                + ("mcq".equals(type)
                    ? "###\nQ: nội dung câu hỏi\nA: đáp án A\nB: đáp án B\nC: đáp án C\nD: đáp án D\nANS: chữ cái đáp án đúng (A/B/C/D)\nSOL: lời giải ngắn gọn\n"
                    : "###\nQ: đề bài\nSOL: lời giải chi tiết\n")
                + "Không thêm lời dẫn hay giải thích nào khác.";
        String out = GeminiService.generate(cfg, spec, null, null);
        if (out == null) return "AI không phản hồi (kiểm tra API key / model trong Cấu hình AI).";
        int n = QuestionDao.importFromAi(out, topicId, type, level, "ai", uid(req));
        return n > 0 ? "AI đã sinh và thêm " + n + " câu hỏi." : "AI trả về định dạng không đọc được, hãy thử lại.";
    }
}
