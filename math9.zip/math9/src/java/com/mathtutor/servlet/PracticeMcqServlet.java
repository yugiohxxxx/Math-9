package com.mathtutor.servlet;

import com.mathtutor.util.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

/** GET: hiển thị đề trắc nghiệm. POST (/student/practice-submit): chấm bài, nhờ AI nhận xét câu sai. */
@WebServlet({"/student/practice-mcq", "/student/practice-submit"})
public class PracticeMcqServlet extends BaseServlet {

    private Map<String, Object> session(HttpServletRequest req, Integer sid) {
        return sid == null ? null : Db.one("SELECT ps.SessionId, ps.PracticeType, ps.Score, ps.FinishedAt, t.Title AS TopicTitle "
                + "FROM PracticeSessions ps JOIN Topics t ON t.TopicId=ps.TopicId WHERE ps.SessionId=? AND ps.StudentId=?", sid, uid(req));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer sid = intParam(req, "sessionId");
        Map<String, Object> ps = session(req, sid);
        if (ps == null) { fail(req, resp, 404, "Không tìm thấy phiên luyện tập."); return; }
        if (ps.get("finishedAt") != null) { redirect(req, resp, "/student/practice-result?sessionId=" + sid); return; }
        List<Map<String, Object>> qs = Db.query("SELECT q.QuestionId, q.Content, q.ImageUrl, q.Level FROM PracticeAnswers pa "
                + "JOIN Questions q ON q.QuestionId=pa.QuestionId WHERE pa.SessionId=? ORDER BY pa.AnswerId", sid);
        for (Map<String, Object> q : qs)
            q.put("options", Db.query("SELECT OptionId, OptionLabel, Content FROM QuestionOptions WHERE QuestionId=? ORDER BY OptionLabel", q.get("questionId")));
        req.setAttribute("practice", ps);
        req.setAttribute("questions", qs);
        view(req, resp, "student/practice-mcq.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer sid = intParam(req, "sessionId");
        Map<String, Object> ps = session(req, sid);
        if (ps == null) { fail(req, resp, 404, "Không tìm thấy phiên luyện tập."); return; }
        if (ps.get("finishedAt") != null) { redirect(req, resp, "/student/practice-result?sessionId=" + sid); return; }

        GeminiService.Cfg cfg = GeminiService.load("grade_mcq");
        List<Map<String, Object>> answers = Db.query("SELECT pa.AnswerId, q.QuestionId, q.Content, q.Solution FROM PracticeAnswers pa "
                + "JOIN Questions q ON q.QuestionId=pa.QuestionId WHERE pa.SessionId=? ORDER BY pa.AnswerId", sid);
        int correct = 0;
        for (Map<String, Object> a : answers) {
            Integer chosen = intParam(req, "q" + a.get("questionId"));
            Map<String, Object> right = Db.one("SELECT OptionLabel, Content FROM QuestionOptions WHERE QuestionId=? AND IsCorrect=1", a.get("questionId"));
            boolean ok = false;
            Map<String, Object> sel = null;
            if (chosen != null) {
                sel = Db.one("SELECT OptionLabel, Content, IsCorrect FROM QuestionOptions WHERE OptionId=? AND QuestionId=?", chosen, a.get("questionId"));
                ok = sel != null && Boolean.TRUE.equals(sel.get("correct"));
            }
            String comment = null;
            if (!ok) {
                String solution = (String) a.get("solution");
                String prompt = cfg.prompt + "\n\nCâu hỏi: " + a.get("content")
                        + "\nĐáp án đúng: " + (right == null ? "" : right.get("optionLabel") + ". " + right.get("content"))
                        + "\nHọc sinh chọn: " + (sel == null ? "(bỏ trống)" : sel.get("optionLabel") + ". " + sel.get("content"))
                        + (solution == null ? "" : "\nLời giải mẫu: " + solution)
                        + "\nHãy nhận xét ngắn gọn (tối đa 4 câu, tiếng Việt, công thức trong $...$): vì sao chưa đúng và gợi ý cách làm.";
                String ai = GeminiService.generate(cfg, prompt, null, null);
                comment = ai != null ? Text.aiToHtml(ai) : (chosen == null ? "Bạn chưa chọn đáp án." : null);
            }
            if (ok) correct++;
            Db.update("UPDATE PracticeAnswers SET SelectedOptionId=?, IsCorrect=?, AiComment=?, AnsweredAt=GETDATE() WHERE AnswerId=?",
                    chosen == null ? null : (sel == null ? null : chosen), ok ? 1 : 0, comment, a.get("answerId"));
        }
        BigDecimal score = answers.isEmpty() ? BigDecimal.ZERO
                : BigDecimal.valueOf(correct * 10.0 / answers.size()).setScale(2, java.math.RoundingMode.HALF_UP);
        Db.update("UPDATE PracticeSessions SET FinishedAt=GETDATE(), Score=? WHERE SessionId=?", score, sid);
        redirect(req, resp, "/student/practice-result?sessionId=" + sid);
    }
}
