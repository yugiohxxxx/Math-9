package com.mathtutor.servlet;

import com.mathtutor.util.Db;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/admin/users")
public class UsersServlet extends BaseServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("users", Db.query("SELECT u.UserId, u.Username, u.FullName, u.Email, r.RoleName, u.IsActive "
                + "FROM Users u JOIN Roles r ON r.RoleId=u.RoleId ORDER BY u.UserId"));
        view(req, resp, "admin/users.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = intParam(req, "id");
        String action = param(req, "action");
        if (id != null && id == uid(req)) {
            flash(req, "Không thể khoá/xoá chính tài khoản đang đăng nhập.");
        } else if (id != null && "toggle".equals(action)) {
            Db.update("UPDATE Users SET IsActive = CASE WHEN IsActive=1 THEN 0 ELSE 1 END WHERE UserId=?", id);
            flash(req, "Đã cập nhật trạng thái tài khoản.");
        } else if (id != null && "delete".equals(action)) {
            try {
                Db.update("DELETE FROM TeacherStudent WHERE TeacherId=? OR StudentId=?", id, id);
                Db.update("DELETE FROM Users WHERE UserId=?", id);
                flash(req, "Đã xoá người dùng.");
            } catch (Db.DbException e) {
                flash(req, "Không xoá được vì người dùng đã có dữ liệu liên quan. Hãy dùng nút Khoá.");
            }
        }
        redirect(req, resp, "/admin/users");
    }
}
