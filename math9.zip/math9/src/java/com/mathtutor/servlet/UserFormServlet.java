package com.mathtutor.servlet;

import com.mathtutor.util.*;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/admin/user-form")
public class UserFormServlet extends BaseServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = intParam(req, "id");
        if (id != null)
            req.setAttribute("u", Db.one("SELECT UserId, Username, FullName, Email, Phone, RoleId FROM Users WHERE UserId=?", id));
        req.setAttribute("roles", Db.query("SELECT RoleId, RoleName FROM Roles ORDER BY RoleId"));
        view(req, resp, "admin/user-form.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = intParam(req, "id");
        String pass = req.getParameter("password");
        try {
            if (id == null) {
                Db.insert("INSERT INTO Users(Username,PasswordHash,FullName,Email,Phone,RoleId,CreatedBy) VALUES(?,?,?,?,?,?,?)",
                        param(req, "username"), Security.sha256(pass), param(req, "fullName"),
                        Text.nullIfBlank(req.getParameter("email")), Text.nullIfBlank(req.getParameter("phone")),
                        intParam(req, "roleId"), uid(req));
            } else {
                Db.update("UPDATE Users SET FullName=?, Email=?, Phone=?, RoleId=? WHERE UserId=?",
                        param(req, "fullName"), Text.nullIfBlank(req.getParameter("email")),
                        Text.nullIfBlank(req.getParameter("phone")), intParam(req, "roleId"), id);
                if (!Text.blank(pass))
                    Db.update("UPDATE Users SET PasswordHash=? WHERE UserId=?", Security.sha256(pass), id);
            }
            flash(req, "Đã lưu người dùng.");
            redirect(req, resp, "/admin/users");
        } catch (Db.DbException e) {
            flash(req, "Không lưu được: tên đăng nhập hoặc email đã tồn tại.");
            redirect(req, resp, "/admin/user-form" + (id == null ? "" : "?id=" + id));
        }
    }
}
