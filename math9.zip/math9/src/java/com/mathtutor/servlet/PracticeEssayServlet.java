package com.mathtutor.servlet;

import com.mathtutor.util.*;
import java.io.IOException;
import java.util.*;
import java.util.regex.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;

/**
 * Tự luận giải TỪNG BƯỚC với AI:
 *  - AI đưa ra bước hiện tại và DỪNG LẠI yêu cầu học sinh nhập số liệu/kết quả (hoặc tải ảnh bài viết tay).
 *  - Học sinh gửi -> AI nhận xét bước đó và đưa bước kế tiếp (hoặc DONE).
 */
@WebServlet("/student/practice-essay")
@MultipartConfig(maxFileSize = 10 * 1024 * 1024)
public class PracticeEssayServlet extends BaseServlet {
    private static final int MAX_STEPS = 10;

    private Map<String, Object> session(HttpServletRequest req, Integer sid) {
        return sid == null ? null : Db.one("SELECT ps.SessionId, ps.PracticeType, ps.Score, ps.FinishedAt, t.Title AS TopicTitle "
                + "FROM PracticeSessions ps JOIN Topics t ON t.TopicId=ps.TopicId WHERE ps.SessionId=? AND ps.StudentId=?", sid, uid(req));
    }

    private List<Map<String, Object>> answers(int sid) {
        return Db.query("SELECT AnswerId, QuestionId, IsCorrect, EssayImageUrl FROM PracticeAnswers WHERE SessionId=? ORDER BY AnswerId", sid);
    }

    private List<Map<String, Object>> steps(Object answerId) {
        return Db.query("SELECT StepId, StepNo, AiPrompt, StudentInput, AiResponse, IsStepCorrect FROM AiSolveSteps WHERE AnswerId=? ORDER BY StepNo", answerId);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer sid = intParam(req, "sessionId");
        Map<String, Object> ps = session(req, sid);
        if (ps == null) { fail(req, resp, 404, "Không tìm thấy phiên luyện tập."); return; }
        List<Map<String, Object>> ans = answers(sid);
        int idx = intParam(req, "index") == null ? 1 : Math.max(1, Math.min(ans.size(), intParam(req, "index")));
        Map<String, Object> a = ans.get(idx - 1);
        Map<String, Object> q = Db.one("SELECT QuestionId, Content, ImageUrl, Solution FROM Questions WHERE QuestionId=?", a.get("questionId"));
        boolean finished = a.get("correct") != null;

        List<Map<String, Object>> st = steps(a.get("answerId"));
        if (!finished && st.isEmpty()) { // bước 1 do AI mở đầu
            String first = firstPrompt(q);
            Db.update("INSERT INTO AiSolveSteps(AnswerId,StepNo,AiPrompt) VALUES(?,1,?)", a.get("answerId"), first);
            st = steps(a.get("answerId"));
        }
        List<Map<String, Object>> done = new ArrayList<>();
        String current = null;
        for (Map<String, Object> s : st) {
            if (s.get("studentInput") == null && s.get("aiResponse") == null) current = (String) s.get("aiPrompt");
            else done.add(s);
        }
        req.setAttribute("practice", ps);
        req.setAttribute("question", q);
        req.setAttribute("currentIndex", idx);
        req.setAttribute("totalQuestions", ans.size());
        req.setAttribute("steps", done);
        req.setAttribute("currentPrompt", current);
        req.setAttribute("finished", finished);
        req.setAttribute("hasNext", idx < ans.size());
        view(req, resp, "student/practice-essay.jsp");
    }

    private String firstPrompt(Map<String, Object> q) {
        GeminiService.Cfg cfg = GeminiService.load("solve_step");
        String out = GeminiService.generate(cfg, cfg.prompt + "\n\nĐỀ BÀI: " + q.get("content")
                + (q.get("solution") == null ? "" : "\nLỜI GIẢI THAM KHẢO (chỉ để bạn đối chiếu, KHÔNG tiết lộ): " + q.get("solution"))
                + "\n\nHãy bắt đầu với BƯỚC 1: nêu ngắn gọn hướng làm của bước đầu tiên (không giải luôn cả bài), rồi yêu cầu học sinh nhập kết quả/số liệu của bước này. "
                + "Tiếng Việt, công thức trong $...$.", null, null);
        return out != null ? Text.aiToHtml(out)
                : "Hãy nêu hướng giải và nhập kết quả / đáp số của bạn cho đề bài này. <i>(AI chưa được cấu hình nên hệ thống sẽ hiển thị lời giải mẫu sau khi bạn gửi.)</i>";
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer sid = intParam(req, "sessionId");
        Map<String, Object> ps = session(req, sid);
        if (ps == null) { fail(req, resp, 404, "Không tìm thấy phiên luyện tập."); return; }
        List<Map<String, Object>> ans = answers(sid);
        Integer qid = intParam(req, "questionId");
        int idx = 0;
        Map<String, Object> a = null;
        for (int i = 0; i < ans.size(); i++)
            if (qid != null && qid.equals(ans.get(i).get("questionId"))) { a = ans.get(i); idx = i + 1; }
        if (a == null) { redirect(req, resp, "/student/practice"); return; }
        String back = "/student/practice-essay?sessionId=" + sid + "&index=" + idx;
        if (a.get("correct") != null) { redirect(req, resp, back); return; }

        if ("finish".equals(param(req, "action"))) {
            finish(a.get("answerId"), sid);
            redirect(req, resp, back);
            return;
        }

        List<Map<String, Object>> st = steps(a.get("answerId"));
        Map<String, Object> pending = null;
        for (Map<String, Object> s : st) if (s.get("studentInput") == null && s.get("aiResponse") == null) pending = s;
        if (pending == null) { redirect(req, resp, back); return; }

        String input = Text.nullIfBlank(req.getParameter("studentInput"));
        Part img = req.getPart("image");
        byte[] imgBytes = partBytes(img);
        String imgPath = store(imgBytes, partName(img), "essays");
        if (input == null && imgPath == null) {
            flash(req, "Hãy nhập kết quả của bước này hoặc tải lên ảnh bài giải (png/jpg).");
            redirect(req, resp, back);
            return;
        }
        if (imgPath != null) Db.update("UPDATE PracticeAnswers SET EssayImageUrl=? WHERE AnswerId=?", imgPath, a.get("answerId"));
        Db.update("UPDATE AiSolveSteps SET StudentInput=? WHERE StepId=?", input != null ? input : "(ảnh bài giải viết tay)", pending.get("stepId"));

        Map<String, Object> q = Db.one("SELECT Content, Solution FROM Questions WHERE QuestionId=?", qid);
        int stepNo = ((Number) pending.get("stepNo")).intValue();
        GeminiService.Cfg cfg = GeminiService.load("solve_step");

        StringBuilder hist = new StringBuilder();
        for (Map<String, Object> s : st) {
            if (s == pending) continue;
            hist.append("Bước ").append(s.get("stepNo")).append(" - AI hỏi: ").append(s.get("aiPrompt"))
                .append("\n  Học sinh: ").append(s.get("studentInput"))
                .append("\n  Nhận xét: ").append(s.get("aiResponse")).append("\n");
        }
        String prompt = cfg.prompt + "\n\nĐỀ BÀI: " + q.get("content")
                + (q.get("solution") == null ? "" : "\nLỜI GIẢI THAM KHẢO (chỉ để đối chiếu): " + q.get("solution"))
                + "\n\nLỊCH SỬ:\n" + hist
                + "\nBƯỚC " + stepNo + " - AI đã hỏi: " + pending.get("aiPrompt")
                + "\nHọc sinh trả lời: " + (input != null ? input : "(xem ảnh đính kèm)")
                + "\n\nHãy nhận xét bước này và đưa ra bước kế tiếp. Trả lời ĐÚNG định dạng sau (tiếng Việt, công thức trong $...$):\n"
                + "CORRECT: yes hoặc no\nFEEDBACK: nhận xét ngắn gọn về bước vừa rồi (nếu sai, chỉ chỗ sai và gợi ý, không giải hộ toàn bộ)\n"
                + "NEXT: yêu cầu cho bước tiếp theo (dừng lại để học sinh nhập số liệu mới) - hoặc viết DONE nếu bài đã hoàn thành.";
        String out = GeminiService.generate(cfg, prompt, imgBytes, imgPath == null ? null : mimeOf(imgPath));

        boolean correct;
        String feedback, next;
        if (out == null) { // chưa có AI: kết thúc bước và hiển thị lời giải mẫu
            correct = false;
            feedback = "AI chưa được cấu hình hoặc không phản hồi nên chưa chấm được. "
                    + (q.get("solution") == null ? "" : "<br><b>Lời giải mẫu:</b><br>" + q.get("solution"));
            next = "DONE";
        } else {
            String c = Text.section(out, "CORRECT", "FEEDBACK", "NEXT");
            correct = c != null && c.toLowerCase().startsWith("y");
            String fb = Text.section(out, "FEEDBACK", "NEXT", "CORRECT");
            feedback = Text.aiToHtml(fb != null ? fb : out);
            String nx = Text.section(out, "NEXT", "CORRECT", "FEEDBACK");
            next = nx == null ? "DONE" : nx;
        }
        Db.update("UPDATE AiSolveSteps SET AiResponse=?, IsStepCorrect=? WHERE StepId=?", feedback, correct ? 1 : 0, pending.get("stepId"));

        boolean done = next.trim().toUpperCase().startsWith("DONE") || stepNo >= MAX_STEPS;
        if (done) finish(a.get("answerId"), sid);
        else Db.update("INSERT INTO AiSolveSteps(AnswerId,StepNo,AiPrompt) VALUES(?,?,?)", a.get("answerId"), stepNo + 1, Text.aiToHtml(next));
        redirect(req, resp, back);
    }

    /** Kết thúc 1 câu tự luận: đúng khi mọi bước đã trả lời đều đúng. Nếu hết câu thì chốt điểm phiên luyện tập. */
    private void finish(Object answerId, int sid) {
        List<Map<String, Object>> st = steps(answerId);
        int answered = 0, wrong = 0;
        StringBuilder text = new StringBuilder(), comment = new StringBuilder();
        for (Map<String, Object> s : st) {
            if (s.get("studentInput") == null) continue;
            answered++;
            text.append("Bước ").append(s.get("stepNo")).append(": ").append(s.get("studentInput")).append("\n");
            if (!Boolean.TRUE.equals(s.get("stepCorrect"))) {
                wrong++;
                if (s.get("aiResponse") != null) comment.append("<b>Bước ").append(s.get("stepNo")).append(":</b> ").append(s.get("aiResponse")).append("<br>");
            }
        }
        boolean ok = answered > 0 && wrong == 0;
        Db.update("UPDATE PracticeAnswers SET IsCorrect=?, EssayText=?, AiComment=?, AnsweredAt=GETDATE() WHERE AnswerId=?",
                ok ? 1 : 0, text.length() == 0 ? null : text.toString(), comment.length() == 0 ? null : comment.toString(), answerId);
        if (Db.count("SELECT COUNT(*) FROM PracticeAnswers WHERE SessionId=? AND IsCorrect IS NULL", sid) == 0)
            Db.update("UPDATE PracticeSessions SET FinishedAt=GETDATE(), Score=(SELECT CAST(SUM(CASE WHEN IsCorrect=1 THEN 1.0 ELSE 0 END)*10/COUNT(*) AS DECIMAL(5,2)) "
                    + "FROM PracticeAnswers WHERE SessionId=?) WHERE SessionId=?", sid, sid);
    }
}
