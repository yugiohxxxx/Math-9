package com.mathtutor.servlet;

import com.mathtutor.util.Db;
import com.mathtutor.util.Security;
import java.io.IOException;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends BaseServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s != null && s.getAttribute("user") != null) { redirect(req, resp, "/home"); return; }
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String u = param(req, "username"), p = req.getParameter("password");
        Map<String, Object> user = (u == null || p == null) ? null : Db.one(
                "SELECT u.UserId, u.Username, u.FullName, u.Email, r.RoleName FROM Users u "
                + "JOIN Roles r ON r.RoleId=u.RoleId WHERE u.Username=? AND u.PasswordHash=? AND u.IsActive=1",
                u, Security.sha256(p));
        if (user == null) {
            req.setAttribute("error", "Sai tên đăng nhập hoặc mật khẩu.");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }
        HttpSession old = req.getSession(false);
        if (old != null) old.invalidate();
        req.getSession(true).setAttribute("user", user);
        redirect(req, resp, "/home");
    }
}
