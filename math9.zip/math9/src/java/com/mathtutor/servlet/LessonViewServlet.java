package com.mathtutor.servlet;

import com.mathtutor.util.*;
import java.io.IOException;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/student/lesson")
public class LessonViewServlet extends BaseServlet {
    private static final String UPSERT =
        "MERGE LessonProgress AS t USING (SELECT ? AS s, ? AS l) AS src ON t.StudentId=src.s AND t.LessonId=src.l "
        + "WHEN MATCHED THEN UPDATE SET Status = CASE WHEN ?='in_progress' AND t.Status='completed' THEN t.Status ELSE ? END, LastViewedAt=GETDATE() "
        + "WHEN NOT MATCHED THEN INSERT(StudentId,LessonId,Status,LastViewedAt) VALUES(src.s,src.l,?,GETDATE());";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = intParam(req, "id");
        Map<String, Object> l = id == null ? null : Db.one(
            "SELECT l.LessonId, l.TopicId, l.Title, l.ContentType, l.ContentHtml, l.VideoUrl, l.IframeUrl, t.Title AS TopicTitle "
            + "FROM Lessons l JOIN Topics t ON t.TopicId=l.TopicId WHERE l.LessonId=?"
            + ("student".equals(role(req)) ? " AND l.IsPublished=1" : ""), id);
        if (l == null) { fail(req, resp, 404, "Không tìm thấy bài giảng."); return; }
        l.put("embedUrl", Text.embedUrl((String) l.get("videoUrl")));
        if ("student".equals(role(req))) Db.update(UPSERT, uid(req), id, "in_progress", "in_progress", "in_progress");
        req.setAttribute("lesson", l);
        view(req, resp, "student/lesson.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = intParam(req, "id");
        if (id != null && "student".equals(role(req))) {
            String st = "completed".equals(param(req, "status")) ? "completed" : "in_progress";
            Db.update(UPSERT, uid(req), id, st, st, st);
            flash(req, "Đã đánh dấu bài giảng là đã học xong. 🎉");
        }
        redirect(req, resp, "/student/lesson?id=" + id);
    }
}
